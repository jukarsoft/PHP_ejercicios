<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script type="text/javascript" src='https://code.jquery.com/jquery-3.3.1.min.js'></script>
	<style type="text/css">
		div.wraper {
			width:500px; 
			border:2px solid black; 
			border-radius:5px; 
			text-align:justify; padding:20px; 
			margin:auto;
			background-color: palegreen;
		}
		label {
			width: 120px;
			display: inline-block;
		}
	</style>
</head>
<body>
	<div class='wraper'> 
		<h2>ALTA FORO</h2>
		<span></span><br><br>
		<form> 
			<label>NIF Usuario: </label><input type="text" name="nif" id="nif"><br>
			<label>Nombre: </label><input type="text" name="nombre" id="nombre"><br>
			<label>Apellidos: </label><input type="text" name="apellidos" id="apellidos"><br>
			<label>Email: </label><input type="email" name="email" id="email"><br>
			<label>Password: </label><input type="password" name="password" id="password"><br><br>
			<input type="button" name="alta" id="alta" value="Alta usuario" >
		</form><br><br>
		
		<a href="examen_login.php">Volver a login</a>
	</div><br>
</body>
</html>