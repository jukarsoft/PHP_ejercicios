
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style type="text/css">
		div.wraper {
			width:500px; 
			border:2px solid black; 
			border-radius:5px; 
			text-align:justify; padding:20px; 
			margin:auto;
			background-color: palegreen;
		}
		label {
			width: 120px;
			display: inline-block;
		}
	</style>
</head>
<body>
	<div class='wraper'> 
		<h2>LOGIN FORO</h2>
		<span></span><br><br>
		<form> 
			<label>NIF Usuario: </label><input type="text" id="nif"><br>
			<label>Password: </label><input type="password" id="password"><br><br>
			<input type="button" id="logon" value="Log in" >
		</form><br><br>

		<a href="examen_alta.php">Darse de alta como usuario</a><br><br>
	</div><br>
</body>
</html>