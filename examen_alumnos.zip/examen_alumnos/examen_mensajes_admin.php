<?php

	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style type="text/css">
		div.wraper {
			width:500px; 
			border:2px solid black; 
			border-radius:5px; 
			text-align:justify; padding:20px; 
			margin:auto;
			background-color: palegreen;
		}
		label {
			width: 120px;
			display: inline-block;
		}
	</style>
</head>
<body>
	<div class='wraper'> 
		<h2>MENSAJES FORO</h2>
		<span></span><br><br>
		<form enctype="multipart/form-data">
			<textarea style="width:300px; height:50px" id="texto"></textarea><br>
			<label>Subir foto: </label><input type="file" id="foto" /><br><br>
			<input type="button" id="enviar" value="Comenta" >
			<input type="button" id="borrar" value="Borrar comentarios" >
			<input type="button" id="logoff" value='logoff'><br><br>
			<span></span><br>
		</form>
	</div><br>
</body>
</html>